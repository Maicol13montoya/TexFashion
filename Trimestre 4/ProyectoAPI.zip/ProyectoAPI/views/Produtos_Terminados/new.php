<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear <div class="card w-75 m-auto">

            </div>
            <form action="?controller=ProductosTerminados&method=saveProductoTerminado" method="post">
                <div class="card-body">
                    <input type="hidden" id="idProductos" name="idProductos" required>
                    <div class="mb-3">
                        <label class="form-label">Nombre del Producto</label>
                        <input type="text" class="form-control" name="Nombre_Producto" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Cantidad Disponible</label>
                        <input type="number" class="form-control" name="Cantidad_Disponible" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descripción</label>
                        <textarea class="form-control" name="Descripcion" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fecha de Entrada</label>
                        <input type="date" class="form-control" name="Fecha_Entrada" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fecha de Salida</label>
                        <input type="date" class="form-control" name="Fecha_Salida" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Materia Prima</label>
                        <select name="idmateria_prima" class="form-control">
                            <option value="">Seleccione...</option>
                            <?php foreach ($materia_prima as $materia): ?>
                                <option value="<?php echo $materia->id ?>"><?php echo $materia->nombre ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Estado</label>
                        <select name="idEstado" class="form-control">
                            <option value="">Seleccione...</option>
                            <?php foreach ($estados as $estado): ?>
                                <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary" id="submit">Actualizar</button>
                    </div>
                </div>
            </form>
    </div>