<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear Nuevo Usuario</h2>
    </div>

    <div class="card-body">
        <form action="?controller=Usuarios&method=update" method="post" onsubmit="return validarFormulario()">
            <input type="hidden" id="id" name="id" value="<?php echo $data[0]->id ?>">

            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Nombres</label>
                        <input type="text" class="form-control" name="nombre" value="<?php echo $data[0]->nombre ?>" required>
                    </div>
                    <div class="col">
                        <label class="form-label">Apellidos</label>
                        <input type="text" class="form-control" name="apellido" value="<?php echo $data[0]->apellido ?>" required>
                    </div>
                </div>
            </div>

            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Tipo Documento</label>
                        <select name="tipo_doc" class="form-control" required>
                            <option value="">Seleccione...</option>
                            <?php foreach ($tipos_doc as $tipo_doc) {
                                if ($tipo_doc->IdDocumento == $data[0]->tipo_documento) {
                            ?>
                                    <option selected value="<?php echo $tipo_doc->IdDocumento ?>"><?php echo $tipo_doc->TipoDocumento ?></option>
                                <?php } else { ?>
                                    <option value="<?php echo $tipo_doc->IdDocumento ?>"><?php echo $tipo_doc->TipoDocumento ?></option>
                            <?php } } ?>
                        </select>
                    </div>
                    <div class="col">
                        <label class="form-label">Documento</label>
                        <input type="number" class="form-control" name="documento" value="<?php echo $data[0]->documento ?>" required>
                    </div>
                </div>
            </div>

            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Correo Electrónico</label>
                        <input type="email" class="form-control" name="correo" value="<?php echo $data[0]->correo_electronico ?>" required>
                    </div>
                    <div class="col">
                        <label class="form-label">Dirección</label>
                        <input type="text" class="form-control" name="direccion" value="<?php echo $data[0]->direccion ?>" required>
                    </div>
                </div>
            </div>

            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Teléfono</label>
                        <input type="number" class="form-control" name="telefono" value="<?php echo $data[0]->telefono ?>" required>
                    </div>
                    <div class="col">
                        <label class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" name="fecha_nacimiento" value="<?php echo $data[0]->fecha_nacimiento ?>" required>
                    </div>
                </div>
            </div>

            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Rol</label>
                        <select name="rol" class="form-control" required>
                            <option value="">Seleccione...</option>
                            <?php foreach ($roles as $rol) {
                                if ($rol->idRol == $data[0]->rol) {
                            ?>
                                    <option selected value="<?php echo $rol->idRol ?>"><?php echo $rol->Rol ?></option>
                                <?php } else { ?>
                                    <option value="<?php echo $rol->idRol ?>"><?php echo $rol->Rol ?></option>
                            <?php } } ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-group d-flex justify-content-center">
                <button class="btn btn-primary" id="submit">Actualizar</button>
            </div>
        </form>
    </div>
</div>

<script>
    function validarFormulario() {
        // Obtener el valor del documento
        var documento = document.querySelector('[name="documento"]').value;
        // Validar que el documento tenga exactamente 10 caracteres
        if (documento.length !== 10) {
            alert("El documento debe tener exactamente 10 caracteres.");
            return false;
        }

        // Obtener el valor del teléfono
        var telefono = document.querySelector('[name="telefono"]').value;
        // Validar que el teléfono tenga exactamente 10 dígitos
        if (telefono.length !== 10) {
            alert("El número de teléfono debe tener exactamente 10 dígitos.");
            return false;
        }

        // Obtener la fecha de nacimiento
        var fechaNacimiento = new Date(document.querySelector('[name="fecha_nacimiento"]').value);
        var fechaActual = new Date();
        var edad = fechaActual.getFullYear() - fechaNacimiento.getFullYear();
        var mes = fechaActual.getMonth() - fechaNacimiento.getMonth();
        if (mes < 0 || (mes === 0 && fechaActual.getDate() < fechaNacimiento.getDate())) {
            edad--;
        }

        // Validar que la persona tenga al menos 18 años
        if (edad < 18) {
            alert("Debe ser mayor de 18 años.");
            return false;
        }

        return true;  // Si pasa todas las validaciones, permitir el envío
    }
</script>
