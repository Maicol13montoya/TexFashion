<?php
require 'models/Usuario.php';
require 'models/Tipo_documento.php';
require 'models/Rol.php';

class UsuariosController
{
    private $model;
    private $tipos_doc;
    private $roles;

    public function __construct()
    {
        try {
            $this->model = new Usuarios;
            $this->tipos_doc = new TipoDocumento;
            $this->roles = new Rol;
            if (!isset($_SESSION['user'])) {
                header('Location: ?controller=login');
            }
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    public function index()
    {
        if (isset($_SESSION['user'])) {
            $UsuariosController = $this->model->getAll();
            $arrTipoDoc = [];
            $arrRol = [];
            foreach ($UsuariosController as $Usuarios) {
                $tipos_doc = $this->model->getTipoDocumento($Usuarios->id);
                array_push($arrTipoDoc, $tipos_doc);
            }
            foreach ($UsuariosController as $Usuarios) {
                $roles = $this->model->getRoles($Usuarios->id);
                array_push($arrRol, $roles);
            }
            ob_start();
            require 'views/Usuarios/list.php';
            $content = ob_get_clean();
            require 'views/home.php';
        } else {
            require 'views/login.php';
        }
    }

    public function add()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $correo = $_POST['correo'];
            $tipo_doc = $_POST['tipo_doc'];
            $documento = $_POST['documento'];
            $direccion = $_POST['direccion'];
            $fecha_nacimiento = $_POST['fecha_nacimiento'];
            $telefono = $_POST['telefono'];
            $rol = $_POST['rol'];

            $this->model->newUsuarios(
                $nombre,
                $apellido,
                $correo,
                $tipo_doc,
                $documento,
                $direccion,
                $fecha_nacimiento,
                $telefono,
                $rol
            );

            // Redirigir después de agregar el producto
            header('Location: ?controller=Usuarios&method=index');
            exit();
        }

        $tipos_doc = $this->tipos_doc->getAll();
        $roles = $this->roles->getAll();

        ob_start();
        require 'views/Usuarios/new.php'; // La vista del formulario de creación
        $content = ob_get_clean();
        require 'views/home.php';
    }

    public function save()
    {
        // Filtrar los datos que vienen del formulario
        $data = [
            'nombre' => $_POST['nombre'],
            'apellido' => $_POST['apellido'],
            'correo_electronico' => $_POST['correo'],
            'tipo_documento' => $_POST['tipo_doc'],
            'documento' => $_POST['documento'],
            'direccion' => $_POST['direccion'],
            'fecha_nacimiento' => $_POST['fecha_nacimiento'],
            'telefono' => $_POST['telefono'],
            'rol' => $_POST['rol'],
        ];

        // Llamar al modelo para realizar la inserción
        $this->model->newUsuarios($data);

        // Redirigir después de guardar
        header('Location: ?controller=Usuarios&method=index');
    }

    public function edit()
    {
        if (isset($_REQUEST['id'])) {
            $id = $_REQUEST['id'];
            $data = $this->model->getUsuariosId($id);
            $tipos_doc = $this->model->getTipoDocumento($id);
            $roles = $this->model->getRoles($id);

            ob_start();
            require 'views/Usuarios/edit.php';
            $content = ob_get_clean();
            require 'views/home.php';
        } else {
            echo "Error: 'id' no está definido.";
        }
    }


    public function update()
    {
        if (isset($_POST)) {
            $dataUsuarios = [
                'id' => $_POST['id'],
                'nombre' => $_POST['nombre'],
                'apellido' => $_POST['apellido'],
                'correo_electronico' => $_POST['correo'],
                'tipo_documento' => $_POST['tipo_doc'],
                'documento' => $_POST['documento'],
                'direccion' => $_POST['direccion'],
                'fecha_nacimiento' => $_POST['fecha_nacimiento'],
                'telefono' => $_POST['telefono'],
                'rol' => $_POST['rol']
            ];
            $respMovie = $this->model->editUsuarios($dataUsuarios);

            header('Location: ?controller=Usuarios&method=index');
        }
    }

    public function delete()
    {
        $this->model->deleteUsuarios($_REQUEST);
        header('Location: ?controller=Usuarios&method=index');
    }
}
