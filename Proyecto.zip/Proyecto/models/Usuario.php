<?php

/**
 * Modelo de la Tabla users
 */
class Usuarios
{
	private $id;
	private $name;
	private $email;
	private $password;
	private $status_id;
	private $roles_id;
	private $pdo;

	public function __construct()
	{
		try {
			$this->pdo = new Database;
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}

	public function getAll()
	{
		try {
			$strSql = "SELECT * FROM usuario u JOIN rol r WHERE u.rol = r.idRol";
			//Llamado al metodo general que ejecuta un select a la BD
			$query = $this->pdo->select($strSql);
			//retorna el objeto del query
			return $query;
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}
	public function getcliente()
	{
		try {
			$strSql = "SELECT * FROM usuario WHERE rol = 4";
			//Llamado al metodo general que ejecuta un select a la BD
			$query = $this->pdo->select($strSql);
			//retorna el objeto del query
			return $query;
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}

	public function getUsuariosPTAll()
	{
		try {
			$strSql = "SELECT * FROM usuario WHERE rol = 4";
			//Llamado al metodo general que ejecuta un select a la BD
			$query = $this->pdo->select($strSql);
			//retorna el objeto del query
			return $query;
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}
	
	public function newUsuarios($data)
	{
		try {
			$this->pdo->insert('usuario', $data);
			return true;
		} catch (PDOException $e) {
			return $e->getMessage();
		}
	}

	public function getUsuariosId($id)
	{
		try {
			$strSql = 'SELECT * FROM usuario u JOIN rol r ON u.rol = r.idRol JOIN documento d ON u.tipo_documento = d.IdDocumento WHERE u.id = :id';
			$arrayData = ['id' => $id];
			$query = $this->pdo->select($strSql, $arrayData);
			return $query;
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}

	public function editUsuarios($data)
	{
		try {
			$strWhere = 'id = ' . $data['id'];
			$this->pdo->update('usuario', $data, $strWhere);
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}

	public function deleteUsuarios($data)
	{
		try {
			$strWhere = 'id = ' . $data['id'];
			$this->pdo->delete('usuario', $strWhere);
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}

	public function getTipoDocumento($id)
	{
		try {
			$strSql = "SELECT IdDocumento, TipoDocumento FROM documento";
			$query = $this->pdo->select($strSql);
			return $query;
		} catch (PDOException $e) {
			return $e->getMessage();
		}
	}

	public function getRoles()
	{
		try {
			$strSql = "SELECT idRol, Rol FROM rol";
			$query = $this->pdo->select($strSql);
			return $query;
		} catch (PDOException $e) {
			return $e->getMessage();
		}
	}
}
