<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear Nuevo Usuario</h2>
    </div>

    <div class="card-body">
        <form action="?controller=Usuarios&method=update" method="post">
            <input type="hidden" id="id" name="id" value="<?php echo $data[0]->id ?>">
            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Nombres</label>
                        <input type="text" class="form-control" name="nombre" value="<?php echo $data[0]->nombre ?>">
                    </div>
                    <div class="col">
                        <label class="form-label">Apellidos</label>
                        <input type="text" class="form-control" name="apellido" value="<?php echo $data[0]->apellido ?>">
                    </div>
                </div>
            </div>
            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Tipo Documento</label>
                        <select name="tipo_doc" class="form-control" required>
                            <option value="">Seleccione...</option>
                            <?php foreach ($tipos_doc as $tipo_doc) {
                                if ($tipo_doc->IdDocumento == $data[0]->tipo_documento) {
                            ?>
                                    <option selected value="<?php echo $tipo_doc->IdDocumento ?>"><?php echo $tipo_doc->TipoDocumento ?></option>
                                <?php } else {
                                ?>
                                    <option value="<?php echo $tipo_doc->IdDocumento ?>"><?php echo $tipo_doc->TipoDocumento ?></option>
                            <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col">
                        <label class="form-label">Documento</label>
                        <input type="number" class="form-control" name="documento" value="<?php echo $data[0]->documento ?>">
                    </div>
                </div>
            </div>
            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Correo Electronico</label>
                        <input type="text" class="form-control" name="correo" value="<?php echo $data[0]->correo_electronico ?>">
                    </div>
                    <div class="col">
                        <label class="form-label">Dirección</label>
                        <input type="text" class="form-control" name="direccion" value="<?php echo $data[0]->direccion ?>">
                    </div>
                </div>
            </div>

            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Teléfono</label>
                        <input type="number" class="form-control" name="telefono" value="<?php echo $data[0]->telefono ?>">
                    </div>
                    <div class="col">
                        <label class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" name="fecha_nacimiento" value="<?php echo $data[0]->fecha_nacimiento ?>">
                    </div>
                </div>
            </div>

            <div class="col mb-4">
                <div class="row">
                    <div class="col">
                        <label class="form-label">Rol</label>
                        <select name="rol" class="form-control" required>
                            <option value="">Seleccione...</option>
                            <?php foreach ($roles as $rol) {
                                if ($rol->idRol == $data[0]->rol) {
                            ?>
                                    <option selected value="<?php echo $rol->idRol ?>"><?php echo $rol->Rol ?></option>
                                <?php } else {
                                ?>
                                    <option value="<?php echo $rol->idRol ?>"><?php echo $rol->Rol ?></option>
                            <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-group d-flex justify-content-center">
                <button class="btn btn-primary" id="submit">Actualizar</button>
            </div>
        </form>
    </div>
</div>