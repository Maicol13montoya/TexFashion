<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear <div class="card w-75 m-auto">

    </div>
    <form action="?controller=ProductosTerminados&method=saveProductoTerminado" method="post">
        <div class="card-body">
            <input type="hidden" id="idProductos" name="idProductos" value="<?php echo $data[0]->idProductos ?>">
            <div class="mb-3">
                <label class="form-label">Nombre del Producto</label>
                <input type="text" class="form-control" name="Nombre_Producto" value="<?php echo $data[0]->Nombre_Producto ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Cantidad Disponible</label>
                <input type="number" class="form-control" name="Cantidad_Disponible" value="<?php echo $data[0]->Cantidad_Disponible ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Descripción</label>
                <textarea class="form-control" name="Descripcion"><?php echo $data[0]->Descripcion ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha de Entrada</label>
                <input type="date" class="form-control" name="Fecha_Entrada" value="<?php echo $data[0]->Fecha_Entrada ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha de Salida</label>
                <input type="date" class="form-control" name="Fecha_Salida" value="<?php echo $data[0]->Fecha_Salida ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Materia Prima</label>
                <select name="idmateria_prima" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($materia_prima as $materia) {
                        if ($materia->id == $data[0]->idmateria_prima) { ?>
                            <option selected value="<?php echo $materia->id ?>"><?php echo $materia->nombre ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $materia->id ?>"><?php echo $materia->nombre ?></option>
                    <?php }
                    } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Estado</label>
                <select name="idEstado" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($estados as $estado) {
                        if ($estado->idEstados == $data[0]->idEstado) { ?>
                            <option selected value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                    <?php }
                    } ?>
                </select>
            </div>
            <div class="form-group">
                <button class="btn btn-primary" id="submit">Actualizar</button>
            </div>
        </div>
    </form>
</div>