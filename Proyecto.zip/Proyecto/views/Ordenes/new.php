<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear Nueva Orden</h2>
    </div>

    <div class="card-body">
        <form action="?controller=Ordenes&method=save" method="post">
            <div class="mb-3">
                <label class="form-label">Cliente</label>
                <select name="idCliente" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($usuarios as $cliente): ?>
                        <option value="<?php echo $cliente->id ?>"><?php echo $cliente->nombre . ' ' . $cliente->apellido ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Orden</label>
                <input type="date" class="form-control" name="Fecha_Orden" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Total</label>
                <input type="number" class="form-control" name="Total_Total" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Cantidad Producto</label>
                <input type="number" class="form-control" name="Cantidad_Producto" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Entrega</label>
                <input type="date" class="form-control" name="Fecha_Entrega" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Producto Terminado</label>
                <select name="idProductosTerminados" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($productosTerminados as $producto): ?>
                        <option value="<?php echo $producto->idProductos ?>"><?php echo $producto->Nombre_Producto ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Materia Prima</label>
                <select name="idMateriaPrima" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($materiasPrimas as $materia): ?>
                        <option value="<?php echo $materia->idProducto ?>"><?php echo $materia->Nombre ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Estado</label>
                <select name="estado" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($estados as $estado): ?>
                        <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <button class="btn btn-primary" id="submit">Guardar</button>
            </div>
        </form>
    </div>
</div>