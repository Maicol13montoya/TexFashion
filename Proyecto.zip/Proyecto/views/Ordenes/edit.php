<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Editar Orden</h2>
    </div>

    <div class="card-body">
        <form action="?controller=Ordenes&method=update" method="post">
            <input type="hidden" id="idOrden" name="idOrden" value="<?php echo $data[0]->idOrden ?>">
            <div class="mb-3">
                <label class="form-label">Cliente</label>
                <select name="idCliente" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($usuarios as $cliente) {
                        if ($cliente->id == $data[0]->idCliente) { ?>
                            <option selected value="<?php echo $cliente->id ?>"><?php echo $cliente->nombre . ' ' . $cliente->apellido ?></option>
                        <?php
                        } else {
                        ?>
                            <option value="<?php echo $cliente->id ?>"><?php echo $cliente->nombre . ' ' . $proveedor->apellido ?></option>
                    <?php }
                    } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Orden</label>
                <input type="date" class="form-control" name="Fecha_Orden" value="<?php echo $data[0]->Fecha_Orden ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Total</label>
                <input type="number" class="form-control" name="Total_Total" value="<?php echo $data[0]->Total_Total ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Cantidad Producto</label>
                <input type="number" class="form-control" name="Cantidad_Producto" value="<?php echo $data[0]->Cantidad_Producto ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Entrega</label>
                <input type="date" class="form-control" name="Fecha_Entrega" value="<?php echo $data[0]->Fecha_Entrega ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Producto Terminado</label>
                <select name="idProductosTerminados" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($productosTerminados as $producto) {
                        if ($producto->idProductos == $data[0]->idProductosTerminados) {
                    ?>
                            <option selected value="<?php echo $producto->idProductos ?>"><?php echo $producto->Nombre_Producto ?></option>
                        <?php } else {   ?>

                            <option value="<?php echo $producto->idProductos ?>"><?php echo $producto->Nombre_Producto ?></option>
                    <?php   }
                    } ?>

                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Materia Prima</label>
                <select name="idMateriaPrima" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($materiasPrimas as $materia) {
                        if ($materia->id == $data[0]->idMateriaPrima) {
                    ?>
                            <option selected value="<?php echo $materia->idProducto ?>"><?php echo $materia->Nombre ?></option>
                        <?php } else {
                        ?>
                            <option selected value="<?php echo $materia->idProducto ?>"><?php echo $materia->Nombre ?></option>
                    <?php
                        }
                    } ?>

                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Estado</label>
                <select name="estado" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($estados as $estado) {
                        if ($estado->idEstados == $data[0]->Estado) {
                    ?>
                            <option selected value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                        <?php } else {
                        ?>
                            <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                    <?php
                        }
                    } ?>
                </select>
            </div>
            <div class="form-group">
                <button class="btn btn-primary" id="submit">Guardar</button>
            </div>
        </form>
    </div>
</div>