<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear Factura</h2>
    </div>

    <div class="card-body">
        <form action="?controller=Facturas&method=save" method="post">
            <div class="mb-3">
                <label class="form-label">Cantidad</label>
                <input type="text" class="form-control" name="Cantidad" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Info de Producto</label>
                <select name="Informacion_del_Producto" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($productosTerminados as $producto): ?>
                        <option value="<?php echo $producto->idProductos  ?>"><?php echo $producto->Nombre_Producto ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha de Emision</label>
                <input type="date" class="form-control" name="Fecha_de_Emision" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Precio Total</label>
                <input type="number" class="form-control" name="Precio_Total" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Numero Factura</label>
                <input type="text" class="form-control" name="Numero_Factura" required>
            </div>
            <div class="mb-3">
                <label class="form-label">lugar De Facturación</label>
                <input type="date" class="form-control" name="Direccion_Facturacion" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Cliente</label>
                <select name="idCliente" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($clientes as $cliente): ?>
                        <option value="<?php echo $cliente->id ?>"><?php echo $cliente->NombreCompleto ?></option>
                    <?php endforeach; ?>
                </select>

                <div class="mb-3">
                    <label class="form-label">Estado</label>
                    <select name="Estado_Factura" class="form-control" required>
                        <option value="">Seleccione...</option>
                        <?php foreach ($estados as $estado): ?>
                            <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label"> Fecha Pago</label>
                    <input type="date" class="form-control" name="Fecha_Pago" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Referencia de Pago</label>
                <input type="text" class="form-control" name="Referencia_Pago" required>
            </div>
            <div class="form-group">
                <button class="btn btn-primary" id="submit">Guardar</button>

            </div>
        </form>
    </div>
</div>