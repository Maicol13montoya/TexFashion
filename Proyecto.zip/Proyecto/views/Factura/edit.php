<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear Nuevo Producto</h2>
    </div>
    <form action="?controller=Facturas&method=update" method="post">
        <div class="card-body">
            <input type="hidden" id="idFacturas" name="idFacturas" value="<?php echo $data[0]->idFacturas?>">
            <div class="mb-3">
                <label class="form-label">Cantidad</label>
                <input type="number" class="form-control" name="Cantidad" value="<?php echo $data[0]->Cantidad ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Producto Terminado</label>
                <select name="Informacion_del_Producto" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($productosTerminados as $producto) {
                        if ($producto->idProductos == $data[0]->idProductosTerminados) {
                    ?>
                            <option selected value="<?php echo $producto->idProductos ?>"><?php echo $producto->Nombre_Producto ?></option>
                        <?php } else {   ?>

                            <option value="<?php echo $producto->idProductos ?>"><?php echo $producto->Nombre_Producto ?></option>
                    <?php   }
                    } ?>

                </select>
            <div class="mb-3">
                <label class="form-label">Fecha Emision</label>
                <input type="date" class="form-control" name="Fecha_de_Emision"
                    value="<?php echo $data[0]->Fecha_de_Emision ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Precio total</label>
                <input type="number" class="form-control" name="Precio_Total"
                    value="<?php echo $data[0]->Precio_Total ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Numero Factura</label>
                <input type="text" class="form-control" name="Numero_Factura"
                    value="<?php echo $data[0]->Numero_Factura?>">
            </div>
            <div class="mb-3">
                <label class="form-label">lugar De Facturación</label>
                <input name="Direccion_Facturacion" class="form-control"
                    value="<?php echo $data[0]->Direccion_Facturacion ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Cliente</label>
                <select name="idCliente" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($usuarios as $proveedor) {
                        if ($proveedor->id == $data[0]->idCliente) {
                            ?>
                            <option selected value="<?php echo $proveedor->id ?>">
                                <?php echo $proveedor->NombreCompleto ?>
                            </option>
                        <?php } else { ?>
                            <option value="<?php echo $proveedor->id ?>">
                                <?php echo $proveedor->NombreCompleto ?>
                            </option>
                        <?php }
                    } ?>
                </select>
            </div>
            
            
       
            <div class="mb-3">
                <label class="form-label">Estado</label>
                <select name="Estado_Factura" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($estados as $estado) {
                        if ($estado->idEstados == $data[0]->Estado_Factura) {
                            ?>
                            <option selected value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                        <?php } else {
                            ?>
                            <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                            <?php
                        }
                    }
                    ?>
                </select>
            </div>
                <div class="mb-3">
                    <label class="form-label">Fecha de pago</label>
                    <input type="date" class="form-control" name="Fecha_Pago"
                        value="<?php echo $data[0]->Fecha_Pago ?>">
                </div>


                <div class="mb-3">
                    <label class="form-label">Referencia de factura</label>
                    <input type="Text" class="form-control" name="Referencia_Pago"
                        value="<?php echo $data[0]->Referencia_Pago ?>">
                        </div>
                
                        <div class="form-group">
                <button class="btn btn-primary" id="submit">Actualizar</button>
            </div>   </div>
    </form>
</div>