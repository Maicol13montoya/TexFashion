<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear Nuevo Producto</h2>
    </div>

    <div class="card-body">
        <form action="?controller=MateriaPriema&method=save" method="post">
            <div class="mb-3">
                <label class="form-label">Nombre</label>
                <input type="text" class="form-control" name="Nombre" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Descripción</label>
                <textarea class="form-control" name="Descripcion" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Ingreso</label>
                <input type="date" class="form-control" name="Fecha_Ingreso" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Precio Unidad</label>
                <input type="number" class="form-control" name="Precio_Unidad" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Cantidad Stock</label>
                <input type="number" class="form-control" name="Cantidad_Stock" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Proveedor</label>
                <select name="id_Proveedor" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($usuarios as $proveedor): ?>
                        <option value="<?php echo $proveedor->id ?>"><?php echo $proveedor->nombre . ' ' . $proveedor->apellido ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Categoría</label>
                <select name="categoria" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($categorias as $categoria): ?>
                        <option value="<?php echo $categoria->idCategoria ?>"><?php echo $categoria->Categoria ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Unidad de Medida</label>
                <select name="Unidad_Medida" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($unidad_medidas as $uni_med): ?>
                        <option value="<?php echo $uni_med->MedidaID ?>"><?php echo $uni_med->Uni_Med ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Fecha Actualización</label>
                <input type="date" class="form-control" name="Fecha_Actualizacion" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Estado</label>
                <select name="estado" class="form-control" required>
                    <option value="">Seleccione...</option>
                    <?php foreach ($estados as $estado): ?>
                        <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <button class="btn btn-primary" id="submit">Guardar</button>

            </div>
        </form>
    </div>
</div>