<div class="card w-75 m-auto">
    <div class="card-header container">
        <h2 class="m-auto">Crear Nuevo Producto</h2>
    </div>
    <form action="?controller=MateriaPriema&method=update" method="post">
        <div class="card-body">
            <input type="hidden" id="idProducto" name="idProducto" value="<?php echo $data[0]->idProducto ?>">
            <div class="mb-3">
                <label class="form-label">Nombre</label>
                <input type="text" class="form-control" name="Nombre" value="<?php echo $data[0]->Nombre ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Descripción</label>
                <textarea class="form-control" name="Descripcion"><?php echo $data[0]->Descripcion ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Ingreso</label>
                <input type="date" class="form-control" name="Fecha_Ingreso"
                    value="<?php echo $data[0]->Fecha_Ingreso ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Precio Unidad</label>
                <input type="number" class="form-control" name="Precio_Unidad"
                    value="<?php echo $data[0]->Precio_Unidad ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Cantidad Stock</label>
                <input type="number" class="form-control" name="Cantidad_Stock"
                    value="<?php echo $data[0]->Cantidad_Stock ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Proveedor</label>
                <select name="id_Proveedor" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($proveedores as $proveedor) {
                        if ($proveedor->id == $data[0]->id_Proveedor) {
                            ?>
                            <option selected value="<?php echo $proveedor->id ?>">
                                <?php echo $proveedor->nombre . ' ' . $proveedor->apellido ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $proveedor->id ?>">
                                <?php echo $proveedor->nombre . ' ' . $proveedor->apellido ?></option>
                        <?php }
                    } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Categoría</label>
                <select name="categoria" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($categorias as $categoria) {
                        if ($categoria->idCategoria == $data[0]->Categoria) {
                            ?>
                            <option selected value="<?php echo $categoria->idCategoria ?>"><?php echo $categoria->Categoria ?>
                            </option>
                        <?php } else {
                            ?>
                            <option value="<?php echo $categoria->idCategoria ?>"><?php echo $categoria->Categoria ?></option>
                            <?php

                        }
                    } ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Unidad de Medida</label>
                <select name="Unidad_Medida" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($unidadMedidas as $uni_med) {
                        if ($uni_med->MedidaID == $data[0]->Unidad_Medida) {
                            ?>
                            <option selected value="<?php echo $uni_med->MedidaID ?>"><?php echo $uni_med->Uni_Med ?></option>
                        <?php } else {
                            ?>
                            <option value="<?php echo $uni_med->MedidaID ?>"><?php echo $uni_med->Uni_Med ?></option>
                            <?php
                        }
                    } ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Fecha Actualización</label>
                <input type="date" class="form-control" name="Fecha_Actualizacion"
                    value="<?php echo $data[0]->Fecha_Actualizacion ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Estado</label>
                <select name="estado" class="form-control">
                    <option value="">Seleccione...</option>
                    <?php foreach ($estados as $estado) {
                        if ($estado->idEstados == $data[0]->Estado) {
                            ?>
                            <option selected value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                        <?php } else {
                            ?>
                            <option value="<?php echo $estado->idEstados ?>"><?php echo $estado->Estados ?></option>
                            <?php
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <button class="btn btn-primary" id="submit">Actualizar</button>
            </div>
        </div>
    </form>
</div>