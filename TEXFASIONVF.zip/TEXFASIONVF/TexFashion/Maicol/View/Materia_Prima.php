<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Materia Prima</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(90deg, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 1) 0%, rgba(0, 100, 148, 1) 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            max-width: 1200px;
            margin-top: 20px;
        }

        h1, h3 {
            color: #003366;
            font-weight: bold;
        }

        .btn {
            border-radius: 8px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
            transition: all 0.2s ease;
        }

        .btn-primary {
            background-color: #0056b3;
            border: none;
        }

        .btn-primary:hover {
            background-color: #004494;
            transform: translateY(-2px);
        }

        .btn-success {
            background-color: #28a745;
        }

        .btn-success:hover {
            background-color: #218838;
        }

        table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            vertical-align: middle !important;
            text-align: center;
            padding: 15px;
            border: 1px solid #007bff;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:hover {
            background-color: #cce5ff;
        }

        label {
            font-weight: bold;
            color: #495057;
        }

        .form-control {
            border-radius: 8px;
            border: 1px solid #007bff;
            padding: 10px;
        }

        .modal-header {
            background-color: #007bff;
            color: white;
        }

        .modal-content {
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
        }

        .modal-title {
            font-weight: bold;
        }

        .btn-close {
            background-color: white;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }
    </style>
</head>

<body>
    <div class="container">
        <h3>Lista de Materia Prima</h3>
<hr>
        <div class="d-flex justify-content-between mb-3">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createModal">
                <i class="fas fa-plus"></i> Crear Nuevo Producto
            </button>
            <form action="../Controller/ControllerMateriaPrima.php" method="post" onsubmit="return validateForm(this);">

                <button class="btn btn-primary mb-3" type="submit" name="Acciones" value="Refrescar tabla">
                    <i class="fas fa-sync-alt"></i> Refrescar tabla
                </button>
            </form>
        </div>

        <div class="table-responsive mt-4">
            <p>Buscar Materia Prima</p>
            <form class="d-flex mb-3" action="..\Controller\ControllerMateriaPrima.php" method="post">
                <input class="form-control me-2" type="number" name="idProducto" placeholder="ID de Producto" aria-label="Search">
                <button class="btn btn-outline-success" type="submit" name="Acciones" value="BuscarProducto">
                    <i class="fas fa-search"></i> Buscar
                </button>
            </form>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID Producto</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Fecha Ingreso</th>
                        <th>Precio Unidad</th>
                        <th>Cantidad Stock</th>
                        <th>Proveedor</th>
                        <th>Categoría</th>
                        <th>Unidad Medida</th>
                        <th>Fecha Actualización</th>
                        <th>Estado</th>
                        <th>Actualizar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (isset($resultado) && $resultado->num_rows > 0) {
                        while ($fila = mysqli_fetch_assoc($resultado)) { ?>
                            <tr>
                                <td><?= htmlspecialchars($fila['idProducto']) ?></td>
                                <td><?= htmlspecialchars($fila['Nombre']) ?></td>
                                <td><?= htmlspecialchars($fila['Descripcion']) ?></td>
                                <td><?= htmlspecialchars($fila['Fecha_Ingreso']) ?></td>
                                <td><?= htmlspecialchars($fila['Precio_Unidad']) ?></td>
                                <td><?= htmlspecialchars($fila['Cantidad_Stock']) ?></td>
                                <td><?= htmlspecialchars($fila['ProveedorNombre']) ?></td>
                                <td><?= htmlspecialchars($fila['CategoriaNombre']) ?></td>
                                <td><?= htmlspecialchars($fila['UnidadMedidaNombre']) ?></td>
                                <td><?= htmlspecialchars($fila['Fecha_Actualizacion']) ?></td>
                                <td><?= htmlspecialchars($fila['EstadoNombre']) ?></td>
                                <td>
                                    <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#updateModal<?= $fila['idProducto'] ?>">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                </td>
                                <td>
                                <form action="../Controller/ControllerMateriaPrima.php" method="post" onsubmit="return validateForm(this);">
 
                                        <input type="hidden" name="idProducto" value="<?= $fila['idProducto'] ?>">
                                        <button type="submit" class="btn btn-danger" name="Acciones" value="BorrarProducto">
                                            <i class="fas fa-trash-alt"></i> Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Modal para actualizar producto -->
                            <div class="modal fade" id="updateModal<?= $fila['idProducto'] ?>" tabindex="-1" aria-labelledby="updateModalLabel<?= $fila['idProducto'] ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Actualizar Producto - ID: <?= $fila['idProducto'] ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                        <form action="../Controller/ControllerMateriaPrima.php" method="post" onsubmit="return validateForm(this);">
   
                                                <input type="hidden" name="idProducto" value="<?= $fila['idProducto'] ?>">
                                                <div class="mb-3">
                                                    <label class="form-label">Nombre</label>
                                                    <input type="text" class="form-control" name="Nombre" value="<?= htmlspecialchars($fila['Nombre']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Descripción</label>
                                                    <textarea class="form-control" name="Descripcion" required><?= htmlspecialchars($fila['Descripcion']) ?></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Fecha Ingreso</label>
                                                    <input type="date" class="form-control" name="Fecha_Ingreso" value="<?= htmlspecialchars($fila['Fecha_Ingreso']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Precio Unidad</label>
                                                    <input type="number" class="form-control" name="Precio_Unidad" value="<?= htmlspecialchars($fila['Precio_Unidad']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Cantidad Stock</label>
                                                    <input type="number" class="form-control" name="Cantidad_Stock" value="<?= htmlspecialchars($fila['Cantidad_Stock']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Proveedor</label>
                                                    <select name="id_Proveedor" class="form-control" required>
                                                        <option value="<?= htmlspecialchars($fila['id_Proveedor']) ?>"><?= htmlspecialchars($fila['ProveedorNombre']) ?></option>
                                                        <option value="">Seleccione...</option>
                                                        <?php foreach ($proveedores as $proveedor): ?>
                                                            <option value="<?= htmlspecialchars($proveedor['Documento']); ?>"><?= htmlspecialchars($proveedor['Nombre_Usuario']); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Categoría</label>
                                                    <select name="Categoria" id="Categoria" class="form-control" required>
                                                        <option value="<?= htmlspecialchars($fila['Categoria']) ?>"><?= htmlspecialchars($fila['CategoriaNombre']) ?></option>
                                                        <option value="">Seleccione...</option>
                                                        <?php foreach ($categorias as $categoria): ?>
                                                            <option value="<?= htmlspecialchars($categoria['idCategoria']); ?>"><?= htmlspecialchars($categoria['Categoria']); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Unidad de Medida</label>
                                                    <select name="Unidad_Medida" class="form-control" required>
                                                        <option value="<?= htmlspecialchars($fila['Unidad_Medida']) ?>"><?= htmlspecialchars($fila['UnidadMedidaNombre']) ?></option>
                                                        <option value="">Seleccione...</option>
                                                        <?php foreach ($unidadMedida as $uma): ?>
                                                            <option value="<?= htmlspecialchars($uma['MedidaID']); ?>"><?= htmlspecialchars($uma['Uni_Med']); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="form-label">Fecha Actualización</label>
                                                    <input type="date" class="form-control" name="Fecha_Actualizacion" value="<?= htmlspecialchars($fila['Fecha_Actualizacion']) ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Estado</label>
                                                    <select name="Estado" class="form-control" required>
                                                        <option value="<?= htmlspecialchars($fila['Estado']) ?>"><?= htmlspecialchars($fila['EstadoNombre']) ?></option>
                                                        <option value="">Seleccione...</option>
                                                        <?php foreach ($estados as $estado): ?>
                                                            <option value="<?= htmlspecialchars($estado['idEstados']); ?>"><?= htmlspecialchars($estado['Estados']); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <button type="submit" class="btn btn-primary" name="Acciones" value="ActualizarProducto">
                                                    <i class="fas fa-save"></i> Actualizar
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php }
                    } else { ?>
                        <tr>
                            <td colspan="13">No hay productos en la base de datos.</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Modal para crear producto -->
        <div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="createModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="createModalLabel">Crear Nuevo Producto</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                    <form action="../Controller/ControllerMateriaPrima.php" method="post" onsubmit="return validateForm(this);">
 
                            <div class="mb-3">
                                <label class="form-label">Nombre</label>
                                <input type="text" class="form-control" name="Nombre" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Descripción</label>
                                <textarea class="form-control" name="Descripcion" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Fecha Ingreso</label>
                                <input type="date" class="form-control" name="Fecha_Ingreso" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Precio Unidad</label>
                                <input type="number" class="form-control" name="Precio_Unidad" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Cantidad Stock</label>
                                <input type="number" class="form-control" name="Cantidad_Stock" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Proveedor</label>
                                <select name="id_Proveedor" class="form-control" required>
                                    <option value="">Seleccione...</option>
                                    <?php foreach ($proveedores as $proveedor): ?>
                                        <option value="<?= htmlspecialchars($proveedor['Documento']); ?>"><?= htmlspecialchars($proveedor['Nombre_Usuario']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Categoría</label>
                                <select name="Categoria" class="form-control" required>
                                    <option value="">Seleccione...</option>
                                    <?php foreach ($categorias as $categoria): ?>
                                        <option value="<?= htmlspecialchars($categoria['idCategoria']); ?>"><?= htmlspecialchars($categoria['Categoria']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Unidad de Medida</label>
                                <select name="Unidad_Medida" class="form-control" required>
                                    <option value="">Seleccione...</option>
                                    <?php foreach ($unidadMedida as $unidad): ?>
                                        <option value="<?= htmlspecialchars($unidad['MedidaID']); ?>"><?= htmlspecialchars($unidad['Uni_Med']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Fecha Actualización</label>
                                <input type="date" class="form-control" name="Fecha_Actualizacion" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Estado</label>
                                <select name="Estado" class="form-control" required>
                                    <option value="">Seleccione...</option>
                                    <?php foreach ($estados as $estado): ?>
                                        <option value="<?= htmlspecialchars($estado['idEstados']); ?>"><?= htmlspecialchars($estado['Estados']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary" name="Acciones" value="CrearProducto">
                                <i class="fas fa-plus"></i> Crear Producto
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function validateForm(form) {
            const today = new Date().toISOString().split('T')[0]; // Fecha actual
            const fechaIngreso = form['Fecha_Ingreso'].value;
            const fechaActualizacion = form['Fecha_Actualizacion'] ? form['Fecha_Actualizacion'].value : today; // Usar hoy si no hay fecha

            if (fechaIngreso > today) {
                alert('La fecha de ingreso no puede ser futura.');
                return false; // Prevenir el envío del formulario
            }

            if (fechaActualizacion > today) {
                alert('La fecha de actualización no puede ser futura.');
                return false; // Prevenir el envío del formulario
            }

            return true; // Permitir el envío del formulario
        }
    </script>
</body>

</html>
