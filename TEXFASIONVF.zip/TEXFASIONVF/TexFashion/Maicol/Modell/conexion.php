<?php
function Conectarse()
{
    $Conexion = mysqli_connect("localhost", "root", "", "texfashion");
    return $Conexion;
}
?>