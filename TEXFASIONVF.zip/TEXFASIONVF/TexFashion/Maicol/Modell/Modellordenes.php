<?php
include 'Conexion.php';

class Orden
{
    private $idOrden;
    private $idCliente;
    private $Fecha_Orden;
    private $Total_Total;
    private $Cantidad_Producto;
    private $Estado;
    private $Fecha_Entrega;
    private $idProductosTerminados;
    private $idMateriaPrima ;
    private $Conexion;

    public function __construct($idOrden = null, $idCliente = null, $Fecha_Orden = null, $Total_Total = null, $Cantidad_Producto = null, $Estado = null, $Fecha_Entrega = null, $idProductosTerminados=null, $idMateriaPrima= null)
    {
        $this->idOrden = $idOrden;
        $this->idCliente = $idCliente;
        $this->Fecha_Orden = $Fecha_Orden;
        $this->Total_Total = $Total_Total;
        $this->Cantidad_Producto = $Cantidad_Producto;
        $this->Estado = $Estado;
        $this->Fecha_Entrega = $Fecha_Entrega;
        $this->idProductosTerminados = $idProductosTerminados;
        $this->idMateriaPrima = $idMateriaPrima;

        // Inicializa la conexión
        $this->Conexion = Conectarse();
    }

    /*public function conectar()
    {
        $Conexion = new Conexion();     // Instancia de la clase de conexión
        return $Conexion->conectar();   // Retorna la conexión
    }*/
    
    public function consultarEstados()
    {
        $sql = "SELECT idEstados, Estados FROM estados";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }
    public function consultarProductos()
    {
        $sql = "SELECT idProductos, Nombre_Producto FROM productos_terminados";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }
    public function consultarMP()
    {
        $sql = "SELECT idProducto, Nombre FROM materia_prima";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }

    public function consultarClientes()
    {
        $sql = "SELECT Documento, Nombre_Usuario FROM usuario WHERE rol = 4";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }
    public function agregarOrden($idCliente, $Fecha_Orden, $Total_Total, $Cantidad_Producto, $Estado, $Fecha_Entrega, $idProductosTerminados, $idMateriaPrima)
    {
        $sql = "INSERT INTO orden (idCliente, Fecha_Orden, Total_Total, Cantidad_Producto, Estado, Fecha_Entrega, idProductosTerminados, idMateriaPrima)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("ssssssss", $idCliente, $Fecha_Orden, $Total_Total, $Cantidad_Producto, $Estado, $Fecha_Entrega, $idProductosTerminados, $idMateriaPrima);
        $stmt->execute();
        $stmt->close();
    }

    public function consultarOrden($idOrden)
    {
        $sql = "SELECT * FROM orden WHERE idOrden = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("i", $idOrden);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();
        return $resultado;
    }

    public function consultarOrdenes()
    {
        $sql = "SELECT * FROM orden";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }

    public function borrarOrden($idOrden)
    {
        $sql = "UPDATE orden SET Estado = 4 WHERE idOrden = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("i", $idOrden);
        $resultado = $stmt->execute();
        $stmt->close();
        return $resultado;
    }

    public function actualizarOrden($idOrden, $idCliente, $Fecha_Orden, $Total_Total, $Cantidad_Producto, $Estado, $Fecha_Entrega,  $idProductosTerminados, $idMateriaPrima)
    {
        $sql = "UPDATE orden SET idCliente = ?, Fecha_Orden = ?, Total_Total = ?, Cantidad_Producto = ?, Estado = ?, Fecha_Entrega = ?, idProductosTerminados= ?, idMateriaPrima= ? WHERE idOrden = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("ssssssssi", $idCliente, $Fecha_Orden, $Total_Total, $Cantidad_Producto, $Estado, $Fecha_Entrega, $idProductosTerminados, $idMateriaPrima, $idOrden);
        $resultado = $stmt->execute();
        $stmt->close();
        return $resultado;
    }
    
    public function descripciones() {
        require_once 'conexion.php';
    
        // Crear conexión usando MySQLi
        $conn = Conectarse();
        
        // Verificar la conexión
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    
        $sql = 'SELECT f.Informacion_del_Producto, p.Descripcion FROM facturas f INNER JOIN productos_terminados p ON f.Informacion_del_Producto = p.idProductos';
        $result = $conn->query($sql);
    
        // Comprobar si hay resultados
        $reindexedDescripciones = [];
        if ($result->num_rows > 0) {
            // Recorrer los resultados y reindexar
            while ($row = $result->fetch_assoc()) {
                $reindexedDescripciones[] = $row; // Añadir fila al array
            }
        }
    
        // Reindexar el array para que empiece desde 1
        $reindexedDescripciones = array_values($reindexedDescripciones);
        foreach ($reindexedDescripciones as $key => $value) {
            // Asignar índice que comienza desde 1
            $reindexedDescripciones[$key + 1] = $value;
            unset($reindexedDescripciones[$key]); // Eliminar el índice original
        }
    
        // Cerrar la conexión
        $conn->close();
    
        return $reindexedDescripciones;
    }
    
    public function saberUsuario($numDoc) {
        require_once 'conexion.php';
    
        $conn = Conectarse();
    
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    
        $sql = "SELECT Nombre_Usuario FROM usuario WHERE Documento = ?"; 
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $numDoc);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc(); 
    
        return $result ? $result['Nombre_Usuario'] : 'Usuario no encontrado'; 
    }

    public function consultarEstado($id){

        $sql = "SELECT Estados FROM estados WHERE idEstados =?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $resultado;
    }

    public function consultarProducto($id){
        $sql = "SELECT Nombre_Producto FROM productos_terminados WHERE idProductos =?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $resultado;
    }

    public function consultarMPById($id){
        $sql = "SELECT Nombre FROM materia_prima WHERE idProducto =?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $resultado;
    }

    public function busqueda($busqueda) {
        $sql = "SELECT o.*, u.Nombre_Usuario 
                FROM orden o
                JOIN usuario u ON o.idCliente = u.Documento
                WHERE u.Nombre_Usuario LIKE ? OR o.idOrden = ?";
        
        $stmt = $this->Conexion->prepare($sql);
        $busquedaLike = "%".$busqueda."%";
        $stmt->bind_param("si", $busquedaLike, $busqueda);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        return $resultado;
    }
    
    
    

}

