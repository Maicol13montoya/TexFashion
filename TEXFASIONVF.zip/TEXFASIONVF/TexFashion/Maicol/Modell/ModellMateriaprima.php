<?php
include 'Conexion.php';

class MateriaPrima
{
    private $idProducto;
    private $Nombre;
    private $Descripcion;
    private $Fecha_Ingreso;
    private $Precio_Unidad;
    private $Cantidad_Stock;
    private $id_Proveedor;
    private $Categoria;
    private $Unidad_Medida;
    private $Fecha_Actualizacion;
    private $Estado;
    private $Conexion;

    public function __construct($idProducto = null, $Nombre = null, $Descripcion = null, $Fecha_Ingreso = null, $Precio_Unidad = null, $Cantidad_Stock = null, $id_Proveedor = null, $Categoria = null, $Unidad_Medida = null, $Fecha_Actualizacion = null, $Estado = null)
    {
        $this->idProducto = $idProducto;
        $this->Nombre = $Nombre;
        $this->Descripcion = $Descripcion;
        $this->Fecha_Ingreso = $Fecha_Ingreso;
        $this->Precio_Unidad = $Precio_Unidad;
        $this->Cantidad_Stock = $Cantidad_Stock;
        $this->id_Proveedor = $id_Proveedor;
        $this->Categoria = $Categoria;
        $this->Unidad_Medida = $Unidad_Medida;
        $this->Fecha_Actualizacion = $Fecha_Actualizacion;
        $this->Estado = $Estado;

        // Inicializa la conexión
        $this->Conexion = Conectarse();
    }

    public function agregarProducto($Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock, $id_Proveedor, $Categoria, $Unidad_Medida, $Fecha_Actualizacion, $Estado)
    {
        $sql = "INSERT INTO materia_prima (Nombre, Descripcion, Fecha_Ingreso, Precio_Unidad, Cantidad_Stock, id_Proveedor, Categoria, Unidad_Medida, Fecha_Actualizacion, Estado) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("ssssssssss", $Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock, $id_Proveedor, $Categoria, $Unidad_Medida, $Fecha_Actualizacion, $Estado);
        $stmt->execute();
        $stmt->close();
    }

    public function consultarProducto($idProducto)
    {
        $sql = "SELECT MP.*, E.Estados AS EstadoNombre, C.Categoria AS CategoriaNombre, UM.Uni_Med AS UnidadMedidaNombre, U.Nombre_Usuario AS ProveedorNombre FROM materia_prima AS MP INNER JOIN categorias AS C ON C.idCategoria = MP.Categoria INNER JOIN unidadmedida AS UM ON UM.MedidaID = MP.Unidad_Medida INNER JOIN estados AS E ON E.idEstados = MP.Estado INNER JOIN usuario AS U ON U.Documento = MP.id_Proveedor WHERE MP.idProducto = ? AND U.Rol = 5 AND MP.status = 'IN'";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bind_param("i", $idProducto);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $stmt->close();
        return $resultado;
    }

    public function consultarEstados()
    {
        $sql = "SELECT idEstados, Estados FROM estados";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }

    public function consultarCategorias()
    {
        $sql = "SELECT idCategoria, Categoria FROM categorias ";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }

    public function consultarUM()
    {
        $sql = " SELECT MedidaID, Uni_Med FROM unidadmedida";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }

    public function consultarProductos()
    {
        // Consulta con JOINs para mostrar nombres descriptivos en lugar de IDs
        $sql = "SELECT mp.*, 
       e.Estados AS EstadoNombre, 
       c.Categoria AS CategoriaNombre, 
       um.Uni_Med AS UnidadMedidaNombre, 
       u.Nombre_Usuario AS ProveedorNombre
FROM materia_prima mp
JOIN estados e ON mp.Estado = e.idEstados
JOIN categorias c ON mp.Categoria = c.idCategoria
JOIN unidadmedida um ON mp.Unidad_Medida = um.MedidaId
JOIN usuario u ON mp.id_Proveedor = u.Documento
WHERE u.Rol = 5 AND mp.status = 'IN'";

        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }

    public function consultarProveedor()
    {
        $sql = "SELECT Documento, Nombre_Usuario FROM usuario WHERE Rol = 5";
        $resultado = $this->Conexion->query($sql);
        return $resultado;
    }

    public function borrarProducto($idProducto)
    {
        $sql = "UPDATE materia_prima SET status = 'OUT' WHERE idProducto = ?";
        $stmt = $this->Conexion->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $idProducto);
            $stmt->execute();  // Ejecuta la consulta
            $stmt->close();    // Cierra el statement
        }
    }

    public function actualizarProducto($idProducto, $Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock, $id_Proveedor, $Categoria, $Unidad_Medida, $Fecha_Actualizacion, $Estado)
    {
        $sql = "UPDATE materia_prima SET Nombre = ?, Descripcion = ?, Fecha_Ingreso = ?, Precio_Unidad = ?, Cantidad_Stock = ?, id_Proveedor = ?, Categoria = ?, Unidad_Medida = ?, Fecha_Actualizacion = ?, Estado = ? WHERE idProducto = ?";
        $stmt = $this->Conexion->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("ssssssssssi", $Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock, $id_Proveedor, $Categoria, $Unidad_Medida, $Fecha_Actualizacion, $Estado, $idProducto);
            $stmt->execute();
            $stmt->close();
        }
    }
}
