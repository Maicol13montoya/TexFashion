<?php
session_start();
require_once '../modell/conexion.php';
require_once '../modell/login.php';

class AuthController
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User(); // Eliminado el parámetro PDO
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $password = trim($_POST['password']);

            if (!empty($email) && !empty($password)) {
                $user = $this->userModel->findByEmail($email);

                // Verifica si la contraseña desencriptada coincide con la ingresada
                if ($user && $password === $user['decrypted_password']) {
                    // Inicio de sesión exitoso
                    $_SESSION['user_id'] = $user['ID_ACCESO'];
                    $_SESSION['user_email'] = $email;
                    header('Location: ../VISTA/dashboard/index.html'); // Redirigir al dashboard
                    exit;
                } else {
                    // Credenciales incorrectas
                    $error = "Correo o contraseña incorrectos.";
                }
            } else {
                $error = "Por favor, complete todos los campos.";
            }
        }

        // Renderizar la vista de login con el posible error
        require '../VISTA/login.php';
    }
}
