<?php
require_once '../Modell/Modellordenes.php';

$gestorOrden = new Orden();

// Obtener la lista de órdenes y otros datos
$ordenes = $gestorOrden->consultarOrdenes();
$estados = $gestorOrden->consultarEstados();
$clientes = $gestorOrden->consultarClientes();
$productos = $gestorOrden->consultarProductos();
$mp = $gestorOrden->consultarMP();


$elegirAcciones = isset($_POST['Acciones']) ? $_POST['Acciones'] : "Cargar";

if ($elegirAcciones == 'CrearOrden') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $gestorOrden->agregarOrden(
            $_POST['idCliente'],
            $_POST['Fecha_Orden'],
            $_POST['Total_Total'],
            $_POST['Cantidad_Producto'],
            $_POST['Estado'],
            $_POST['Fecha_Entrega'],
            $_POST['idProductosTerminados'],
            $_POST['idMateriaPrima']
        );
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

} elseif ($elegirAcciones == 'ActualizarOrden') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $gestorOrden->actualizarOrden(
            $_POST['idOrden'],
            $_POST['idCliente'],
            $_POST['Fecha_Orden'],
            $_POST['Total_Total'],
            $_POST['Cantidad_Producto'],
            $_POST['Estado'],
            $_POST['Fecha_Entrega'],
            $_POST['idProductosTerminados'],
            $_POST['idMateriaPrima']
        );
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

} elseif ($elegirAcciones == 'BorrarOrden') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $gestorOrden->borrarOrden($_POST['idOrden']);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

}else {
    $resultado = $gestorOrden->consultarOrdenes();
}

include "../View/ordenes.php";
