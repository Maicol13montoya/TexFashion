<?php
require_once '../model/ordenesModel.php';

$gestorOrden = new Orden();

// Obtener la lista de órdenes
$ordenes = $gestorOrden->consultarOrdenes();

$elegirAcciones = isset($_POST['Acciones']) ? $_POST['Acciones'] : "Cargar";

if ($elegirAcciones == 'CrearOrden' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $gestorOrden->agregarOrden(
        $_POST['Fecha_Orden'],
        $_POST['Total_Total'],
        $_POST['Cantidad_Producto'],
        $_POST['Estado'],
        $_POST['Fecha_Entrega'],
        $_POST['idCliente'], // Asegúrate de tener este campo en tu formulario
        $_POST['idMateriaPrima'] // Asegúrate de tener este campo en tu formulario
    );
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
} elseif ($elegirAcciones == 'ActualizarOrden' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $gestorOrden->actualizarOrden(
        $_POST['idOrden'],
        $_POST['Fecha_Orden'],
        $_POST['Total_Total'],
        $_POST['Cantidad_Producto'],
        $_POST['Estado'],
        $_POST['Fecha_Entrega']
    );
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
} elseif ($elegirAcciones == 'BorrarOrden' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $gestorOrden->borrarOrden($_POST['idOrden']);
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
} elseif ($elegirAcciones == 'BuscarOrden' && !empty($_POST['idOrden'])) {
    $resultado = [$gestorOrden->consultarOrden($_POST['idOrden'])];
} else {
    $resultado = $ordenes;
}

include "../VISTA/ordenes.php";
