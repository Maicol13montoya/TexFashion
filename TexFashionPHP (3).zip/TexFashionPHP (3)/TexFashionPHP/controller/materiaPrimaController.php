<?php
require_once '../model/materiaPrimaModel.php';

$gestorMateriaPrima = new MateriaPrima();

// Obtener la lista de productos de materia prima
$productos = $gestorMateriaPrima->consultarProductos();

$elegirAcciones = isset($_POST['Acciones']) ? $_POST['Acciones'] : "Cargar";

if ($elegirAcciones == 'agregarMateriaPrima') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $gestorMateriaPrima->agregarProducto(
            $_POST['Nombre'],
            $_POST['Descripcion'],
            $_POST['Fecha_Ingreso'],
            $_POST['Precio_Unidad'],
            $_POST['Cantidad_Stock'],
            $_POST['Categoria'],
            $_POST['Unidad_Medida'],
            $_POST['Estado']
        );
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
} elseif ($elegirAcciones == 'ActualizarProducto') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $gestorMateriaPrima->actualizarProducto(
            $_POST['idProducto'],
            $_POST['Nombre'],
            $_POST['Descripcion'],
            $_POST['Fecha_Ingreso'],
            $_POST['Precio_Unidad'],
            $_POST['Cantidad_Stock'],
            $_POST['Categoria'],
            $_POST['Unidad_Medida'],
            $_POST['Estado']
        );
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
} elseif ($elegirAcciones == 'BorrarProducto') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $gestorMateriaPrima->borrarProducto($_POST['idProducto']);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
} elseif ($elegirAcciones == 'BuscarProducto') {
    $resultado = $gestorMateriaPrima->consultarProducto($_POST['idProducto']);
}

include "../VISTA/Materia_Prima.php";
