<?php
require_once '../model/facturasModel.php';

if (isset($_POST['formulario'])) {


    $formulario = $_POST['formulario']; {
        if ($formulario == 'registrarFactura') {


            $cantidadFac = $_POST['Cantidad'];
            $InformacionProducto = $_POST['Informacion_del_Producto'];
            $fechaEmi = $_POST['Fecha_de_Emision'];
            $precioT = $_POST['Precio_Total'];
            $numFactura = $_POST['Numero_Factura'];
            $cliente = $_POST['idCliente'];
            $direccionFactura = $_POST['Direccion_Facturacion'];
            $estadoFactura = $_POST['Estado_Factura'];
            $fechaPago = $_POST['Fecha_Pago'];
            $referenciaPago = $_POST['Referencia_Pago'];

            $registro = registrarFactura($cantidadFac, $InformacionProducto, $fechaEmi, $precioT, $numFactura, $cliente, $direccionFactura, $estadoFactura, $fechaPago, $referenciaPago);

            if ($registro) {
                header("Location: ../VISTA/ListaFacturacion.php");
                return true;
            }
            return false;
        } elseif ($formulario == 'ActualizarFactura') {
            $id = $_POST['idFacturas'];
            $cantidadFac = $_POST['Cantidad'];
            $InformacionProducto = $_POST['Informacion_del_Producto'];
            $fechaEmi = $_POST['Fecha_de_Emision'];
            $precioT = $_POST['Precio_Total'];
            $numFactura = $_POST['Numero_Factura'];
            $cliente = $_POST['idCliente'];
            $direccionFactura = $_POST['Direccion_Facturacion'];
            $estadoFactura = $_POST['Estado_Factura'];
            $fechaPago = $_POST['Fecha_Pago'];
            $referenciaPago = $_POST['Referencia_Pago'];

            $registro = actualizarFacturas($id, $cantidadFac, $InformacionProducto, $fechaEmi, $precioT, $numFactura, $cliente, $direccionFactura, $estadoFactura, $fechaPago, $referenciaPago);

            if ($registro) {
                header("Location: ../VISTA/ListaFacturacion.php");
                return true;
            }
            return false;
        } elseif ($formulario == 'eliminarFacturas') {

            $id =  $_POST['idFacturas'];

            $registro = eliminarFacturas($id);

            if ($registro) {
                header("Location: ../VISTA/ListaFacturacion.php");
                return true;
            }
            return false;
        }
    }
}
