<?php
require_once '../model/proveedoresModel.php';

// Hacer el controlados de proveedore.php, las funciones ya existen en model/proveedorModel.php
