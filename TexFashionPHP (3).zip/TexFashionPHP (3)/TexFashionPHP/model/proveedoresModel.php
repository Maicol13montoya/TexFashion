<?php


function obtenerProveedores()
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'SELECT * FROM usuario WHERE Rol = 5';
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $proveedores = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($proveedores) {
        return $proveedores;
    }
    return [];
}

function registrarProveedor($documento, $nombre, $apellidos, $fechaN, $direccion, $telefono, $rol, $tipoDoc)
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'INSERT INTO usuario (Documento, Nombre_Usuario, Apellidos, Fecha_Nacimiento, Direccion_Usuario, Telefono, Rol, TipoDoc) 
            VALUES (:documento, :nombre, :apellidos, :fechaN, :direccion, :telefono, :rol, :tipoDoc)';
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':documento', $documento);
    $stmt->bindValue(':nombre', $nombre);
    $stmt->bindValue(':apellidos', $apellidos);
    $stmt->bindValue(':fechaN', $fechaN);
    $stmt->bindValue(':direccion', $direccion);
    $stmt->bindValue(':telefono', $telefono);
    $stmt->bindValue(':rol', $rol);
    $stmt->bindValue(':tipoDoc', $tipoDoc);

    if ($stmt->execute()) {
        return true;
    }
    return false;
}


function actualizarProveedor($documento, $nombre, $apellidos, $fechaN, $direccion, $telefono, $tipoDoc)
{
    require_once 'conexion.php';

    $conn = Conectarse();

    // Consulta SQL para actualizar el proveedor basado en el documento
    $sql = 'UPDATE usuario 
            SET Nombre_Usuario = :nombre, 
                Apellidos = :apellidos, 
                Fecha_Nacimiento = :fechaN, 
                Direccion_Usuario = :direccion, 
                Telefono = :telefono, 
                Rol = :rol, 
                TipoDoc = :tipoDoc 
            WHERE Documento = :documento';

    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':documento', $documento);
    $stmt->bindValue(':nombre', $nombre);
    $stmt->bindValue(':apellidos', $apellidos);
    $stmt->bindValue(':fechaN', $fechaN);
    $stmt->bindValue(':direccion', $direccion);
    $stmt->bindValue(':telefono', $telefono);
    $stmt->bindValue(':rol', $rol);
    $stmt->bindValue(':tipoDoc', $tipoDoc);

    // Ejecuta la consulta y devuelve true o false basado en el resultado
    if ($stmt->execute()) {
        return true;
    }
    return false;
}


function eliminarProveedor($id)
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'DELETE FROM usuario WHERE Documento = :id AND Rol = 5';
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':id', $id);

    if ($stmt->execute()) {
        return true;
    }
    return false;
}
