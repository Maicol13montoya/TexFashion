<?php
function obtenerFacturas()
{
    require_once 'conexion.php';

    $conn = Conectarse();
    $sql =  'SELECT * FROM `facturas`';
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $producto = $stmt->fetchAll(PDO::FETCH_ASSOC);


    if ($producto) {
        return $producto;
    }
}
function registrarFactura($cantidadFac, $InformacionProducto, $fechaEmi, $precioT, $numFactura, $cliente, $direccionFactura, $estadoFactura, $fechaPago, $referenciaPago)
{
    // Conexión a la base de datos
    require_once 'conexion.php';

    $conn = Conectarse();

    // Consulta SQL con la cantidad correcta de marcadores de posición
    $sql = "INSERT INTO facturas (`Cantidad`,`Informacion_del_Producto`,`Fecha_de_Emision`,`Precio_Total`,`Numero_Factura`,`idCliente`,`Direccion_Facturacion`,`Estado_Factura`,`Fecha_Pago`,`Referencia_Pago`) Values(?,?,?,?,?,?,?,?,?,?)";

    // Preparar la consulta
    $stmt = $conn->prepare($sql);

    // Ejecutar la consulta con los parámetros correctos
    $stmt->execute([$cantidadFac, $InformacionProducto, $fechaEmi, $precioT, $numFactura, $cliente, $direccionFactura, $estadoFactura, $fechaPago, $referenciaPago]);
}
function actualizarFacturas($id, $cantidadFac, $InformacionProducto, $fechaEmi, $precioT, $numFactura, $cliente, $direccionFactura, $estadoFactura, $fechaPago, $referenciaPago)
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'UPDATE facturas 
            SET Cantidad = :cantidadFac, 
                Informacion_del_Producto = :InformacionProducto,
                Fecha_de_Emision = :fechaEmi, 
                Precio_Total = :precioT, 
                Numero_Factura = :numFactura, 
                idCliente = :cliente, 
                Direccion_Facturacion = :direccionFactura, 
                Estado_Factura = :estadoFactura, 
                Fecha_Pago = :fechaPago, 
                Referencia_Pago = :referenciaPago 
            WHERE idFacturas = :id';

    $stmt = $conn->prepare($sql);

    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->bindValue(':cantidadFac', $cantidadFac);
    $stmt->bindValue(':InformacionProducto', $InformacionProducto);
    $stmt->bindValue(':fechaEmi', $fechaEmi);
    $stmt->bindValue(':precioT', $precioT);
    $stmt->bindValue(':numFactura', $numFactura);
    $stmt->bindValue(':cliente', $cliente);
    $stmt->bindValue(':direccionFactura', $direccionFactura);
    $stmt->bindValue(':estadoFactura', $estadoFactura);
    $stmt->bindValue(':fechaPago', $fechaPago);
    $stmt->bindValue(':referenciaPago', $referenciaPago);

    if ($stmt->execute()) {
        return true;
    }
    return false;
}

function eliminarFacturas($id)
{

    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'DELETE FROM `facturas` WHERE idFacturas = :id';
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':id', $id);

    if ($stmt->execute()) {
        return true;
    }
    return false;
}

function busqueda($busqueda)
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'Select * from facturas where idFacturas like :busqueda';

    $stmt = $conn->prepare($sql);
    $busqueda_conatenada = "%$busqueda%";
    $stmt->bindValue(':busqueda', $busqueda_conatenada);
    $stmt->execute();

    $productos_busqueda = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($productos_busqueda) {
        return $productos_busqueda;
    }
    return null;
}
