
<?php

function obtenerProductosT()
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'SELECT * FROM productos_terminados';
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $producto = $stmt->fetchAll(PDO::FETCH_ASSOC);


    if ($producto) {
        return $producto;
    }
}


function registrarProducto($nombre, $descripcion, $fechaE, $fechaS, $cantidad, $estado, $idMP)
{
    // Conexión a la base de datos
    require_once 'conexion.php';

    $conn = Conectarse();

    // Consulta SQL incluyendo todos los campos del formulario
    $sql = "INSERT INTO productos_terminados (nombre_producto, Cantidad_Disponible, Descripcion, Fecha_Entrada, Fecha_Salida, idEstado, idmateria_prima) 
            VALUES (:nombre, :cantidad, :descripcion, :fechaE, :fechaS, :estado, :idMP)";

    // Preparar la consulta
    $stmt = $conn->prepare($sql);

    // Vincular los parámetros usando bindValue
    $stmt->bindValue(':nombre', $nombre, PDO::PARAM_STR);
    $stmt->bindValue(':cantidad', $cantidad, PDO::PARAM_INT); // Asegúrate de que 'cantidad' sea un entero
    $stmt->bindValue(':descripcion', $descripcion, PDO::PARAM_STR);
    $stmt->bindValue(':fechaE', $fechaE);
    $stmt->bindValue(':fechaS', $fechaS);
    $stmt->bindValue(':estado', $estado, PDO::PARAM_INT); // Asegúrate de que 'estado' sea un entero
    $stmt->bindValue(':idMP', (int)$idMP, PDO::PARAM_INT);  // Asegúrate de que 'idMP' sea un entero

    // Ejecutar la consulta
    if ($stmt->execute()) {
        return true;
    }
    return false;

    // Puedes agregar manejo de errores aquí si lo deseas
}
function actualizarProductos($id, $nombre, $cantidad, $descripcion, $fechaE, $fechaS, $estado)
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql = 'UPDATE productos_terminados SET Nombre_Producto = :nombre, Cantidad_Disponible = :cantidad , Descripcion = :descripcion ,Fecha_Entrada = :fechaE,Fecha_Salida = :fechaS, idEstado = :estado WHERE idProductos = :id';
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':id', $id);
    $stmt->bindValue(':nombre', $nombre);
    $stmt->bindValue(':cantidad', $cantidad);
    $stmt->bindValue(':descripcion', $descripcion);
    $stmt->bindValue(':fechaE', $fechaE);
    $stmt->bindValue(':fechaS', $fechaS);
    $stmt->bindValue(':estado', $estado);


    if ($stmt->execute()) {
        return true;
    }
    return false;
}

function eliminarProducto($id)
{
    require_once 'conexion.php';

    $conn = Conectarse();

    $sql1 = 'DELETE FROM `orden` WHERE idProductosTerminados = :id';
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bindValue(':id', $id);
    $stmt1->execute();

    $sql = 'DELETE FROM `productos_terminados` WHERE idProductos = :id';
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':id', $id);

    if ($stmt->execute()) {
        return true;
    }
    return false;
}



?>