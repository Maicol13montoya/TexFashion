<?php
require_once 'conexion.php'; // Usa include_once para evitar múltiples inclusiones

class Orden
{
    private $Conexion;

    function __construct()
    {
        // Inicializa la conexión usando PDO y asigna a la propiedad de la clase
        $this->Conexion = Conectarse();
    }

    public function agregarOrden($Fecha_Orden, $Total_Total, $Cantidad_Producto, $Estado, $Fecha_Entrega, $idCliente, $idMateriaPrima)
    {
        try {
            $sql = "INSERT INTO orden(Fecha_Orden, Total_Total, Cantidad_Producto, Estado, Fecha_Entrega, idCliente, idMateriaPrima) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $this->Conexion->prepare($sql);

            // Pasa los valores como un array al método execute()
            $stmt->execute([
                $Fecha_Orden,
                $Total_Total,
                $Cantidad_Producto,
                $Estado,
                $Fecha_Entrega,
                $idCliente,
                $idMateriaPrima
            ]);
        } catch (PDOException $e) {
            echo "Error al agregar la orden: " . $e->getMessage();
        }
    }
    public function consultarOrden($idOrden)
    {
        $sql = "SELECT * FROM orden WHERE idOrden = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->execute([$idOrden]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function consultarOrdenes()
    {
        $sql = "SELECT * FROM orden";
        $stmt = $this->Conexion->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function borrarOrden($idOrden)
    {
        $sql = "DELETE FROM orden WHERE idOrden = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->execute([$idOrden]);
    }

    public function actualizarOrden($idOrden, $Fecha_Orden, $Total_Total, $Cantidad_Producto, $Estado, $Fecha_Entrega)
    {
        $sql = "UPDATE orden SET Fecha_Orden = ?, Total_Total = ?, Cantidad_Producto = ?, Estado = ?, Fecha_Entrega = ? 
                WHERE idOrden = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->execute([$Fecha_Orden, $Total_Total, $Cantidad_Producto, $Estado, $Fecha_Entrega, $idOrden]);
    }
}
