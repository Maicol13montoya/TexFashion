<?php


// IMPORTANTE en 'dbname' pongan el nombre de su base de datos. Igualmente yo puse la base de datos ay en el rar -->


function Conectarse()
{
    try {
        $conn = new PDO("mysql:host=localhost; dbname=texfashion_new", 'root', '');
        return $conn;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
