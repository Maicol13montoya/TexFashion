<?php
include 'conexion.php';

class MateriaPrima
{
    private $Conexion;

    public function __construct()
    {
        $this->Conexion = Conectarse();  // Conexión PDO
    }

    public function mostrarEstados(){
        $sql = "SELECT * FROM estados";
        $stmt = $this->Conexion->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function agregarProducto($Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock, $Categoria, $Unidad_Medida, $Estado)
    {
        $sql = "INSERT INTO materia_prima (Nombre, Descripcion, Fecha_Ingreso, Precio_Unidad, Cantidad_Stock, Categoria, Unidad_Medida, Fecha_Actualizacion, Estado) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->execute([$Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock, $Categoria, $Unidad_Medida, $Fecha_Ingreso, $Estado]);
    }

    public function consultarProducto($idProducto)
    {
        $sql = "SELECT * FROM materia_prima WHERE idProducto = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->execute([$idProducto]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function consultarProductos()
    {
        $sql = "SELECT * FROM materia_prima";
        $stmt = $this->Conexion->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function borrarProducto($idProducto)
    {
        $sql = "DELETE FROM materia_prima WHERE idProducto = :id";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->bindValue(':id', $idProducto);
        $stmt->execute();
    }

    public function actualizarProducto($idProducto, $Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock,$Categoria, $Unidad_Medida, $Estado)
    {
        $sql = "UPDATE materia_prima SET Nombre = ?, Descripcion = ?, Fecha_Ingreso = ?, Precio_Unidad = ?, Cantidad_Stock = ?, Categoria = ?, Unidad_Medida = ?, Estado = ? WHERE idProducto = ?";
        $stmt = $this->Conexion->prepare($sql);
        $stmt->execute([$Nombre, $Descripcion, $Fecha_Ingreso, $Precio_Unidad, $Cantidad_Stock, $Categoria, $Unidad_Medida, $Estado, $idProducto]);
    }
}
?>
